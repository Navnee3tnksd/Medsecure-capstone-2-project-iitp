import {z} from "zod";


export const loginSchema = z.object({
  email: z
    .email("Invalid email"),

  password: z
    .string()
    .min(1, "Password required"),
});

export type LoginInput = 
  z.infer<typeof loginSchema>;
